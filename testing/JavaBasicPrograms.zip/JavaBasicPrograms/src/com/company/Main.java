package com.company;

import java.awt.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        //1 print name
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter your name");
//        String name=sc.nextLine();
//        System.out.println("Hello");
//        System.out.println(name);
//        sc.close();
//
//        Enter your name
//        Rohith Surya
//        Hello
//        Rohith Surya



        //2 Sum of two numbers
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter two numbers");
//        int num1= sc.nextInt();
//        int num2=sc.nextInt();
//
//        System.out.println("Sum is: "+(num1+num2));
//        sc.close();
//        enter two numbers
//        74
//        36
//        Sum is: 110



        //3 divide two numbers
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter two numbers");
//        int num1= sc.nextInt();
//        int num2=sc.nextInt();
//
//        System.out.println("Division of the numbers is: "+(num1/num2));
//        sc.close();
//        enter two numbers
//        50
//        3
//        Division of the numbers is: 16



        //4 print result of the following operations
//        System.out.println(-5+8*6);
//        System.out.println((55+9)%9);
//        System.out.println(20+(-3*(5/8)));
//        System.out.println((5+((15/3)*2))-(8%3));


        //5 Multiplication
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter two numbers");
//        int num1= sc.nextInt();
//        int num2=sc.nextInt();
//        System.out.println("Multiplication of the numbers is: "+(num1*num2));
//        sc.close();
//
//        enter two numbers
//        25
//        5
//        Multiplication of the numbers is: 125


        //6 add,sub,mul,div,rem
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter two numbers");
//        int num1= sc.nextInt();
//        int num2=sc.nextInt();
//        System.out.println(num1+" + "+num2+" = "+(num1+num2));
//        System.out.println(num1+" - "+num2+" = "+(num1-num2));
//        System.out.println(num1+" x "+num2+" = "+(num1*num2));
//        System.out.println(num1+" / "+num2+" = "+(num1/num2));
//        System.out.println(num1+" mod "+num2+" = "+(num1%num2));
//        sc.close();
//
//        enter two numbers
//        125 24
//        125 + 24 = 149
//        125 - 24 = 101
//        125 x 24 = 3000
//        125 / 24 = 5
//        125 mod 24 = 5

        //7 Multiplication tables up to 10
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter a number");
//        int num1=sc.nextInt();
//        for (int i=1;i<=10;i++){
//            System.out.println(num1+" x "+i+" = "+(num1*i));
//        }
//        sc.close();
//        Enter a number
//        8
//        8 x 1 = 8
//        8 x 2 = 16
//        8 x 3 = 24
//        8 x 4 = 32
//        8 x 5 = 40
//        8 x 6 = 48
//        8 x 7 = 56
//        8 x 8 = 64
//        8 x 9 = 72
//        8 x 10 = 80


        //8
//        String j = "J";
//        String a = "A";
//        String v = "V";
//        System.out.println("    "+j+"    "+a+"     "+v+"     "+v+"    "+a);
//        System.out.println("    "+j+"   "+a+" "+a+"     "+v+"   "+v+"    "+a+" "+a);
//        System.out.println(j+"   "+j+"  "+a+a+a+a+a+"     "+v+" "+v+"    "+a+a+a+a+a);
//        System.out.println(" "+j+j+"   "+a+"     "+a+"     "+v+"    "+a+"     "+a);


        //9
//        System.out.println(((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)));
//        2.138888888888889

        //10
//        System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));
//        2.9760461760461765


        //11 area and perimeter of a circle
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter radius of the circle");
//        double radius = sc.nextDouble();
//        System.out.println("Perimeter is "+2*Math.PI*radius);
//        System.out.println("Area is "+Math.PI*Math.pow(radius,2));
//
//        Enter radius of the circle
//        7.5
//        Perimeter is 47.12388980384689
//        Area is 176.71458676442586

        //12 average of 3 numbers
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter 3 numbers");
//        int[] arrNum=new int[3];
//        for (int i=0;i<arrNum.length;i++){
//            arrNum[i]= sc.nextInt();
//        }
//
//        double sum=0;
//        for (int i=0;i<arrNum.length;i++){
//           sum=+arrNum[i];
//        }
//        System.out.println(sum/arrNum.length);
//        sc.close();

        //Area and Perimeter of a Rectangle
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Width");
//        double width= sc.nextDouble();
//        System.out.println("Height");
//        double height = sc.nextDouble();
//
//        System.out.println("Area is "+width+" * "+height+" = "+(width*height));
//        System.out.println("Perimeter is "+"2( "+width+" * "+height+" ) = "+2*(width+height));
//        sc.close();
//        Width
//        5.6 8.5
//        Height
//        Area is 5.6 * 8.5 = 47.599999999999994
//        Perimeter is 2( 5.6 * 8.5 ) = 28.2













    }
}
