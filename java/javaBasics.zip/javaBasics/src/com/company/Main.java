package com.company;

import com.company.products.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here

        //1. prime for a range
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter a range");
//        int m=sc.nextInt();
//        int n=sc.nextInt();
//
//        int sum=0;
//        for(int i=m; i<=n;i++){
//            if(isPrime(i)){
//                sum+=i;
//            }
//        }
//        System.out.println(sum);

        //2. factorial of a given number
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        int ans = checkFact(num);
//        System.out.println(ans);
//        sc.close();

        //3 check fibonacci
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        boolean ans = checkFibonacci(num);
//        System.out.println(ans);
//        sc.close();

        //4 decimal to hex string
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        System.out.println(Integer.toBinaryString(num));
//        sc.close();



        //5 binary to decimal
//        Scanner sc = new Scanner(System.in);
//        String num = sc.next();
//        System.out.println(Integer.parseInt(num,2));
//        sc.close();

        //6 each number to word
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        for(int i=0;i<String.valueOf(num).length();i++){
//            System.out.print(digitToWord(String.valueOf(num).charAt(i))+" ");
//        }
//        sc.close();

        //7 entire number to word
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        System.out.println(numberToWord(num));
//        sc.close();


        // 8 item
//        Scanner sc=new Scanner(System.in);
//        List<Item> itemList=new ArrayList<>();
//
//        for(int i=1;i>0;i++){
//            Item item=new Item();
//            System.out.println("enter product "+i+" details");
//            System.out.println("Enter item code");
//            item.setItemCode(sc.nextInt());
//            System.out.println("Enter item description");
//            item.setDescription(sc.next());
//            System.out.println("Enter item quantity");
//            item.setQuantity(sc.nextInt());
//            System.out.println("Enter item price");
//            item.setPrice(sc.nextDouble()*item.getQuantity());
//            itemList.add(item);
//            System.out.println("Do you want to continue? (y/n)");
//            if(sc.next().equalsIgnoreCase("N")){
//                break;
//            }
//        }
//
//        //display all products
//        System.out.println("Your purchases are:");
//        double total=0.0;
//        for (Item i :itemList) {
//            System.out.println(i);
//            total+=i.getPrice();
//
//        }
//
//        if(total>1000){
//            System.out.println("The grand total is: "+total);
//            System.out.println("The discounted total is: "+(total-((0.10)*total)));
//            System.out.println(numberToWord((int)(total-((0.10)*total)))+"rupees only");
//        }
//        else if(total<1000){
//            System.out.println("Are you paying by cash or card?");
//            if (sc.next().equalsIgnoreCase("card")){
//                double surcharge =(0.0025*total);
//                System.out.println("surcharge: "+surcharge);
//                System.out.println("The total is: "+total);
//                System.out.println("The grand total is: "+(total+surcharge));
//                System.out.println(numberToWord((int)(total+surcharge))+"rupees only");
//
//            }
//
//        }else{
//            System.out.println(numberToWord((int)(total))+"rupees only");
//
//        }
//
//        sc.close();


        //9 a fibonacci series
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter the limit:");
//        int num= sc.nextInt();
//        System.out.print("0, 1, 1, ");
//        int x=1;
//        int y=1;
//        int sum=x+y;
//        System.out.print(sum+", ");
//        while (true){
//            x=y;
//            y=sum;
//            sum=x+y;
//            if(sum<num)
//            System.out.print(sum+", ");
//            else{
//                break;
//            }
//        }

            //9 b
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter the limit:");
//        int num= sc.nextInt();
//        int i=1;
//        int j=2;
//        System.out.print(i+", "+j+", ");
//        while (true) {
//            if ((i+3)>num || (j+4)>num){
//                break;
//            }else {
//                System.out.print((i += 3) + ", ");
//                System.out.print((j += 4) + ", ");
//
//            }
//        }
//        sc.close();

        //9c
//        List<Integer> numList=new ArrayList<>();
//        numList.add(1);
//        numList.add(5);
//        numList.add(8);
//        for (Integer i:numList) {
//            System.out.print(i+", ");
//        }
//
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter the limit");
//        int num=sc.nextInt();
//        int i= numList.get(numList.size()-1)+numList.get(numList.size()-2)+numList.get(numList.size()-3);;
//
//        while (i<num){
//            System.out.println(i+", ");
//            numList.add(i);
//            i= numList.get(numList.size()-1)+numList.get(numList.size()-2)+numList.get(numList.size()-3);;
//        }
//        sc.close();


        //10
        System.out.println("Enter base value");
        Scanner sc=new Scanner(System.in);
        int base = sc.nextInt();
        System.out.println("Enter power value in binary");
        String power = sc.next();
        int powerNum = Integer.parseInt(power,2);

        int ans=1;
        for (int i=1;i<=powerNum;i++){
            ans*=base;
        }
        System.out.println(ans);







    }

    private static String numberToWord(int number) {
        String words = "";
        String unitsArray[] = { "zero", "one", "two", "three", "four", "five", "six",
                "seven", "eight", "nine", "ten", "eleven", "twelve",
                "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
                "eighteen", "nineteen" };
        String tensArray[] = { "zero", "ten", "twenty", "thirty", "forty", "fifty",
                "sixty", "seventy", "eighty", "ninety" }; if (number == 0) {
            return "zero";
        }
        if (number < 0) {
            String numberStr = "" + number;
            numberStr = numberStr.substring(1);
            return "minus " + numberToWord(Integer.parseInt(numberStr));
        }
        if ((number / 1000000) > 0) {
            words += numberToWord(number / 1000000) + " million ";
            number %= 1000000;
        }
        if ((number / 1000) > 0) {
            words += numberToWord(number / 1000) + " thousand ";
            number %= 1000;
        }
        if ((number / 100) > 0) {
            words += numberToWord(number / 100) + " hundred ";
            number %= 100;
        } if (number > 0) {
            if (number < 20) {
                words += unitsArray[number];
            } else {
                words += tensArray[number / 10];
                if ((number % 10) > 0) {
                    words += "-" + unitsArray[number % 10];
                }
            }
        }
        return words;
    }

    private static String digitToWord(char ch) {
        switch(ch) {
            case '0': return "Zero";
            case '1': return "One";
            case '2': return "Two";
            case '3': return "Three";
            case '4': return "Four";
            case '5': return "Five";
            case '6': return "Six";
            case '7': return "Seven";
            case '8': return "Eight";
            case '9': return "Nine";
        }
        return "Unknown " + ch ;
    }

    private static boolean checkFibonacci(int num) {
        return  ( isPerfectSquare(5*num*num+4) || isPerfectSquare(5*num*num-4) );
    }

    private static boolean isPerfectSquare(int i) {
        int n =(int) Math.sqrt(i);
        return (i==n*n);
    }

    private static int checkFact(int num) {
        int ans=1;
        if(num<=0){
            return 0;
        }
        for(int i=1;i<=num;i++){
            ans*=i;
        }
        return ans;
    }

    public static boolean isPrime(int num){
        if(num<=1){
            return false;
        }
        for(int i=2;i<=Math.sqrt(num);i++){
            if(num%i==0){
                return false;
            }
        }
        return true;
    }
}
