package com.tbhs.b84;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestjpaProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestjpaProductApplication.class, args);
	}

}
