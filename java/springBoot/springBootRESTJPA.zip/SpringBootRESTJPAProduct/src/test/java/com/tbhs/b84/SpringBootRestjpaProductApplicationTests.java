package com.tbhs.b84;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestjpaProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
