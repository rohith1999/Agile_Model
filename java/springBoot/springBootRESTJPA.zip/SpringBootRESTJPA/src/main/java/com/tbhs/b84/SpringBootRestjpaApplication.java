package com.tbhs.b84;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestjpaApplication.class, args);
	}

}
