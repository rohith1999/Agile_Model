package com.tbhs.b84.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tbhs.b84.model.Book;
import com.tbhs.b84.repository.BookRepository;

@RestController
@RequestMapping("/books")
public class BookController {
	
	@Autowired
	BookRepository 	jp;
	
	@PostMapping("/book")
	public ResponseEntity<Book> save(@RequestBody Book book){
		
		 Book bsave = jp.save(book);
		 return new ResponseEntity<Book>(bsave,HttpStatus.OK);
		
		
	}
	
	@GetMapping("/Allbooks")
	public ResponseEntity<List<Book>> getAllBooks(){
			
	 return new ResponseEntity<List<Book>>(jp.findAll(),HttpStatus.OK);

	}
	
	
	@GetMapping("/getBook/{bookid}")
	public ResponseEntity<Book> getABook(@PathVariable("bookid")  int bookid){
		
//		for(Book b : jp.findAll() ) {
//			if(b.getBookid()==bookid) {
//				return new ResponseEntity<Book>(b,HttpStatus.OK);
//
//			}
//		}
		
		//optional class avoids null pointer exception
		Optional<Book> book= jp.findById(bookid);
		if(book.isPresent()) {
		return new ResponseEntity<Book>(book.get(),HttpStatus.OK);

		}
		
		return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
		
	}	
	
	
	
	//delete a record
	@DeleteMapping("/deleteBook/{bookid}")
	public ResponseEntity<Book> deleteABook(@PathVariable("bookid")  int bookid){
		

		if(jp.existsById(bookid)) {
			jp.deleteById(bookid);
		return new ResponseEntity<Book>(HttpStatus.NO_CONTENT);
		}else
		return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
		
	}
	
}
