package com.tbhs.b84.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tbhs.b84.model.Train;
import com.tbhs.b84.repository.TrainRepository;

@RestController
@RequestMapping("/trains")
public class TrainController {
	
	@Autowired
	TrainRepository repository;
	
	@PostMapping("/train")
	public ResponseEntity<Train> save(@RequestBody Train train){
		
		return new ResponseEntity<Train>(repository.save(train),HttpStatus.OK);
		
		
	}
	
	@GetMapping("/AllTrains")
	public ResponseEntity<List<Train>> getAllBooks(){
			
	 return new ResponseEntity<List<Train>>(repository.findAll(),HttpStatus.OK);

	}
	
	
	@GetMapping("/getTrain/{trainid}")
	public ResponseEntity<Train> getABook(@PathVariable("trainid")  int trainid){
		

		
		//optional class avoids null pointer exception
		Optional<Train> book= repository.findById(trainid);
		if(book.isPresent()) {
		return new ResponseEntity<Train>(book.get(),HttpStatus.OK);

		}
		
		return new ResponseEntity<Train>(HttpStatus.NOT_FOUND);
		
	}	
	
	
	
	//delete a record
	@DeleteMapping("/deleteTrain/{trainid}")
	public ResponseEntity<Train> deleteABook(@PathVariable("trainid")  int trainid){
		

		if(repository.existsById(trainid)) {
			repository.deleteById(trainid);
		return new ResponseEntity<Train>(HttpStatus.NO_CONTENT);
		}else
		return new ResponseEntity<Train>(HttpStatus.NOT_FOUND);
		
	}
	
	
}
