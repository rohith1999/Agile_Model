package com.tbhs.b84.repository;
import java.util.ArrayList;
import java.util.List;

import com.tbhs.b84.model.Person;
public class PersonRepository {

	private List<Person> plist;
	public PersonRepository() {
		
		plist=new ArrayList<>();
		
		Person person=new Person();
		person.setAge(22);
		person.setId(1);
		person.setName("Rohith S");
		
		Person person1=new Person();
		person1.setAge(21);
		person1.setId(2);
		person1.setName("Manju M");
		
		Person person2=new Person();
		person2.setAge(23);
		person2.setId(3);
		person2.setName("Amith G");
		
		plist.add(person);
		plist.add(person1);
		plist.add(person2);
		
		
	}
	
	public List<Person> getAllPersons(){
		
		return plist;
	}
	
}
