package com.tbhs.b84.controller;

import java.text.BreakIterator;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.tbhs.b84.model.Book;
import com.tbhs.b84.repository.BookRepository;


@RestController
@RequestMapping("/books")
public class BookController {

	@GetMapping("/getAllBooks")
	public ResponseEntity<List<Book>> getAllBookDetails(){
		
		BookRepository br=new BookRepository();
		return new ResponseEntity<List<Book>>(br.getAllBooks(),HttpStatus.OK);
		
	}
	
	@GetMapping("/getABook/{bookId}")
	public ResponseEntity<Book> getABook(@PathVariable int bookId){
		BookRepository br=new BookRepository();
		Book b = br.getABook(bookId);
		if(b!=null)
		return new ResponseEntity<Book>(b,HttpStatus.OK);
		else
			return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);

	}
	
}
