package com.tbhs.b84.repository;
import java.util.ArrayList;
import java.util.List;

import com.tbhs.b84.model.Book;
public class BookRepository {

	List<Book> blist;

	public BookRepository() {
		blist =new ArrayList<Book>();
		
		Book b1=new Book();
		b1.setBookId(1);
		b1.setBookName("Java");
		b1.setBookPrice(500);
		
		Book b2=new Book();
		b2.setBookId(2);
		b2.setBookName("C");
		b2.setBookPrice(500);
		
		Book b3=new Book();
		b3.setBookId(3);
		b3.setBookName("C++");
		b3.setBookPrice(500);
		
		
		blist.add(b1);
		blist.add(b2);
		blist.add(b3);
		
	}
	
	
	public List<Book> getAllBooks(){
	 return blist;	
	
	}
	
	
	public Book getABook(int bookId) {
		for(Book b: blist) {
			if(b.getBookId()==bookId) {
				return b;
			}
		}
		return null;
	}
	
}
