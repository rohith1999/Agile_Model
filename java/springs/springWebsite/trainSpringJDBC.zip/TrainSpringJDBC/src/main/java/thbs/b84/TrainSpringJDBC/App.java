package thbs.b84.TrainSpringJDBC;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       
        ApplicationContext ctx=new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");  
        TrainDAO1 dao=(TrainDAO1)ctx.getBean("trainDAO"); 
        
        //insert data
        Train train=new Train(1000,"BulletTrain","Bangalore","Chennai",8000.0);
        dao.insert(train);
        
//        //display data
//        for(Train train1 : dao.selectAll()) {
//        
//        	System.out.println(train1.toString());
//        	
//        }
//        
//        //search data
//        Train searchTrain= dao.select(1001);
//    	System.out.println(searchTrain.toString());
//    	
    	((ClassPathXmlApplicationContext)ctx).close();

        
        
        
    }
}
