package thbs.b84.TrainSpringJDBC;


public interface CRUDOperations {
	
	public void insert(Train train);

}
