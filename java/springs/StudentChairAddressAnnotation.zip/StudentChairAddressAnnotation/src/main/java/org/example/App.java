package org.example;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        //constructor injection
        //student id, name chair,address
        //chair - color ,type

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("org.example");
        context.refresh();


        Student student = (Student) context.getBean("student");



        Chair chair= (Chair) context.getBean("chair");
        chair.setColor("red");
        chair.setType("rotational");

        Address address= (Address) context.getBean("address");
        address.setDoorNo("17");
        address.setState("Karnataka");
        address.setCity("Bangalore");
        address.setStreetNo("2nd cross");

        student.setAddress(address);
        student.setChair(chair);

        System.out.println(student);










    }
}
