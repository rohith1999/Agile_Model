package org.example;


import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("student")
@Setter
public class Student {
    private int id;
    private String name;
    private Address address;
    private Chair chair;

    @Autowired
    public Student(Address address, Chair chair) {
        this.address = address;
        this.chair = chair;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", address=" + address +
                ", chair=" + chair +
                '}';
    }
}
