package pack1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        
    	
    	ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
    	
    	
    	EmployeeDAO employeeDAO= (EmployeeDAO) context.getBean("employeeDAO");
    	
//    	Employee employee = new Employee();
//    	employee.setEmployeeId(3);
//    	employee.setEmployeeName("manju");
//    	employee.setSalary(75000);
//    	employeeDAO.insert(employee);
    	
    	//display all table
    	for(Employee e:employeeDAO.selectAll()) {
    		
    		System.out.println(e);
    		
    	}
    	
    	
    	//search employee
    	Employee searchBook = employeeDAO.select(1000);
    	System.out.println(searchBook);
    	
    	
    	((ClassPathXmlApplicationContext)context).close();
    	
    }
}
