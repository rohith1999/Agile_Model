package pack1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class EmployeeDAO implements EmployeeCRUD {
	private JdbcTemplate jdbcTemplate;
	
	
	

	public EmployeeDAO(JdbcTemplate jdbcTemplate) {
	
		this.jdbcTemplate = jdbcTemplate;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void insert(Employee employee) {
		jdbcTemplate.update("insert into emplooyee values (?,?,?)",
				new Object[] {employee.getEmployeeId(),employee.getEmployeeName(),employee.getSalary()});
		
		
	}

	@Override
	public List<Employee> selectAll() {
		
		
		return jdbcTemplate.query("select * from emplooyee", new RowMapper<Employee>(){@Override
		public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
			// TODO Auto-generated method stub
			Employee employee =new Employee();
			employee.setEmployeeId(rs.getInt(1));
			employee.setEmployeeName(rs.getString(2));
			employee.setSalary(rs.getInt(3));
			return employee;
		}
		
		});
	}

	@Override
	public Employee select(int employeeId) {
		
		
		
		return (Employee)jdbcTemplate.queryForObject("select * from emplooyee where employeeId=?", new Object[] {
		employeeId
		},new RowMapper<Employee>() {
			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee employee=new Employee();
				employee.setEmployeeId(rs.getInt(1));
				employee.setEmployeeName(rs.getString(2));
				employee.setSalary(rs.getInt(3));
				return employee;
			}
		});
	}
	
	
	
	
}
