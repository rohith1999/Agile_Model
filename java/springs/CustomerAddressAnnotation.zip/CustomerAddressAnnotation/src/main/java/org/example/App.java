package org.example;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContextExtensionsKt;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("org.example");
        context.refresh();

        Customer customer= (Customer) context.getBean("customer");
        customer.setName("rohith");
        customer.setId(1);

        Address address= (Address) context.getBean("address");
        address.setDoorNo("17");
        address.setStreetNo("2nd cross");
        address.setState("Karnataka");
        address.setCity("Bangalore");
        address.setPinCode("560032");

        customer.setAddress(address);

        System.out.println(customer.toString());
        context.close();

    }
}
