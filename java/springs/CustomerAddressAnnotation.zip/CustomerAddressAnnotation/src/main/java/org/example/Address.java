package org.example;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString
@Component("address")
public class Address {
private String doorNo;
private String streetNo;
private String city;
private String state;
private String pinCode;


}
