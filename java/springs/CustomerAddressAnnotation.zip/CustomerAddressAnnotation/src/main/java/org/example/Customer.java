package org.example;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Getter
@Component("customer")
@ToString
public class Customer {
private int id;
private String name;
private Address address;

    public Customer(){

    }

//    @Autowired
//    public Customer(Address address) {
//        this.address = address;
//    }


    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Autowired
    public void setAddress(Address address) {
        this.address = address;
    }
}
